package CoverageAgent_Package;

import org.objectweb.asm.ClassVisitor;
import org.objectweb.asm.MethodVisitor;
import org.objectweb.asm.Opcodes;

public class ClassTransformVisitor extends ClassVisitor implements Opcodes {
	String cName = "";

	public ClassTransformVisitor(final ClassVisitor cv) {
		super(ASM5, cv);
	}

	public void visit(int version, int access, String name, String signature, String superName, String[] interfaces) {
		this.cName = name;
		super.visit(version, access, name, signature, superName, interfaces);
	}

	@Override
	public MethodVisitor visitMethod(final int access, final String name, final String desc, final String signature,
			final String[] exceptions) {
		MethodVisitor mv = cv.visitMethod(access, name, desc, signature, exceptions);
		return mv == null ? null : new MethodTransformVisitor(mv, name, cName);
	}
	
	public void visitEnd() {
		System.out.println("}");
	}
}
