package CoverageAgent_Package;
public class Example2 {
	public static void main(String[] args) {
		m4();
	}
	public static void m4() {
		int a=1;
		int b=1;
		int c=a+b;
	}
	public static void m5() {
		m4();
	}
}
