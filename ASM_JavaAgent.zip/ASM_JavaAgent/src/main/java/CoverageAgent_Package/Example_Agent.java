package CoverageAgent_Package;

public class Example_Agent {
	public static void main(String[] args) {
		m1();
		m2();
	}
	public static int m1() {
		int a=1;	
		int b=1;
		int c=a+b;
		return c;
	}
	public static void m2() {
		m1();
		m1();
	}
	public static void m3() {
		m1();
		m1();
		System.out.println("HIM3");
	}
	public static void m4() {
		m1();
		m1();
		System.out.println("HIM4");
	}
}
