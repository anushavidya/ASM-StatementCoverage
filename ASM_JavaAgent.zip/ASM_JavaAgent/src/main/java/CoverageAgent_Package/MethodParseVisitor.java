package CoverageAgent_Package;

import org.objectweb.asm.Label;
import org.objectweb.asm.MethodVisitor;
import org.objectweb.asm.Opcodes;

class MethodParseVisitor extends MethodVisitor implements Opcodes {

	String mName;
	int lineNumber;
	String cName;
    public MethodParseVisitor(final MethodVisitor mv, String name, String className) {
        super(ASM5, mv);
        this.mName=name;
        this.cName=className;
    }
    @Override
    public void visitMethodInsn(int opcode, String owner, String name, String desc)
    {
       System.out.println("********Method Innstruction*****"+name);  	
    }
    
    @Override
    public void visitLineNumber(int line, Label start) {
        this.lineNumber = line;
        System.out.println(lineNumber);
    	StatementCoverageData scov=new StatementCoverageData();
    	scov.BuildProjectHashMapData(lineNumber, mName, cName);
    }
}