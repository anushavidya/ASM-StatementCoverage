package CoverageAgent_Package;

import org.objectweb.asm.Label;
import org.objectweb.asm.MethodVisitor;
import org.objectweb.asm.Opcodes;

class MethodTransformVisitor extends MethodVisitor implements Opcodes {

	String mName;
	int lineNumber;
	String cName;

	public MethodTransformVisitor(final MethodVisitor mv, String name, String className) {
		super(ASM5, mv);
		this.mName = name;
		this.cName = className;
	}

	@Override
	public void visitCode() {
		System.out.println(mName);
		mv.visitFieldInsn(GETSTATIC, "java/lang/System", "out", "Ljava/io/PrintStream;");
		mv.visitLdcInsn(mName + " executed");
		mv.visitMethodInsn(INVOKEVIRTUAL, "java/io/PrintStream", "println", "(Ljava/lang/String;)V", false);
	}

		@Override
		public void visitLineNumber(int line, Label start) {
			mv.visitLdcInsn(line);
			mv.visitLdcInsn(mName);
			mv.visitLdcInsn(cName);
			mv.visitMethodInsn(INVOKESTATIC, "CoverageAgent_Package/StatementCoverageData", "MarkLineAsExecuted",
					"(ILjava/lang/String;Ljava/lang/String;)V", false);
	    	super.visitLabel(start);
			super.visitLineNumber(line, start);
			super.visitLabel(start);
			super.visitLineNumber(lineNumber, start);
		}
}