package CoverageAgent_Package;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;

import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassWriter;

public class ParseClassFile {
	public static void ParseClasses(String[] aList) {
		for (int i = 0; i < aList.length; i++) {
			if (i > 0) {
				try {
					FileInputStream is = new FileInputStream(aList[i]);
					ClassReader cr = new ClassReader(is);
					ClassWriter cw = new ClassWriter(ClassWriter.COMPUTE_FRAMES);
					ClassParseVisitor ca = new ClassParseVisitor(cw);
					cr.accept(ca, 0);
				} catch (IOException e) {
					e.printStackTrace();
				}

			}
		}
	}

}