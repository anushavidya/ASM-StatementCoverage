package CoverageAgent_Package;

import java.lang.instrument.Instrumentation;

public class SimpleAgent {
    public static void premain(String agentArgs, Instrumentation inst) {
        final SimpleClassTransformer transformer = new SimpleClassTransformer(agentArgs);
        inst.addTransformer(transformer);
    }
}
