package CoverageAgent_Package;
import java.lang.instrument.ClassFileTransformer;
import java.lang.instrument.IllegalClassFormatException;
import java.security.ProtectionDomain;

import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassWriter;

public class SimpleClassTransformer implements ClassFileTransformer {
	String agentargs = "";
	String[] aList;

	SimpleClassTransformer(String agentArgs) {
		this.agentargs = agentArgs;
	}

	public byte[] transform(final ClassLoader loader, final String className, final Class<?> classBeingRedefined,
			final ProtectionDomain protectionDomain, final byte[] classfileBuffer) throws IllegalClassFormatException {
		
		byte[] byteCode = classfileBuffer;
		putInArray(agentargs);
		try {
			if (className.contains(aList[0])) {
				ParseClassFile.ParseClasses(aList);
				ClassReader cr = new ClassReader(byteCode);
				ClassWriter cw = new ClassWriter(ClassWriter.COMPUTE_FRAMES);
				ClassTransformVisitor ca = new ClassTransformVisitor(cw);
				cr.accept(ca, 0);
				byteCode=cw.toByteArray();
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return byteCode;
	}
	void putInArray(String list)
	{
		aList = list.split(",");
	}
}
