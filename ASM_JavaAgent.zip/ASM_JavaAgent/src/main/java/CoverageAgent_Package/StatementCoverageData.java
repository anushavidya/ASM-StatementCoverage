package CoverageAgent_Package;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class StatementCoverageData {
	static final Map<String, Integer> coverageHashmap = new HashMap<String, Integer>();

	public static void MarkLineAsExecuted(int lineNumber, String methodName, String className) {
		String str = String.format("%s.%s.%d", className, methodName, lineNumber);
		if (coverageHashmap.containsKey(str)) {
			int k = coverageHashmap.get(str);
			k++;
			coverageHashmap.put(str, k);
		}
		double comp = coverageComputation(0);
		System.out.println(comp + "***Computation***");
	}

	public void BuildProjectHashMapData(int lineNumber, String methodName, String className) {
		String str = String.format("%s.%s.%d", className, methodName, lineNumber);
		if (!coverageHashmap.containsKey(str)) {
			coverageHashmap.put(String.format("%s.%s.%d", className, methodName, lineNumber), 0);
		}
	}

	public static double coverageComputation(int n)// n=0=>
													// statementCoverageForProj,
													// n=1=>statementCoverageForClass
	{
		double c1 = 0.0;
		if (n == 0)
			c1 = statementCoverageForProj();
		else if (n == 1)
			c1 = statementCoverageForClass();
		return c1;
	}

	public static double statementCoverageForProj() {
		double coverage = 0;
		int counter = 0;
		int hashmapCount = coverageHashmap.size();
		Set<String> keys = coverageHashmap.keySet();
		for (Iterator<String> i = keys.iterator(); i.hasNext();) {
			String key = (String) i.next();
			int value = coverageHashmap.get(key);
			if (value > 0)
				counter++;
		}
		coverage = (100.0 * counter / hashmapCount);
		return coverage;
	}

	public static double statementCoverageForClass() {
		double coverage = 0;

		return coverage;

	}
}
