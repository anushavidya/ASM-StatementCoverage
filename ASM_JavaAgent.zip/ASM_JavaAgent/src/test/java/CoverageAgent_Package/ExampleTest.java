package CoverageAgent_Package;
//import Src_Package.Example; 
import org.junit.Test;

public class ExampleTest {

	@Test
	public void m1test() {
		Example.m1();
	}
	
	@Test
	public void m2test() {
		Example.m2();
	}
}