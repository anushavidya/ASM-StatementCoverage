package ASM_StatementCoverage.ASM_SC;

import java.lang.instrument.Instrumentation;

import ASM_StatementCoverage.ASM_SC.SC_ClassFileTransformer;

public class SC_Agent {
    public static void premain(String args, Instrumentation inst) throws Exception {
    	// registers the transformer
        inst.addTransformer(new SC_ClassFileTransformer());
    }
}
