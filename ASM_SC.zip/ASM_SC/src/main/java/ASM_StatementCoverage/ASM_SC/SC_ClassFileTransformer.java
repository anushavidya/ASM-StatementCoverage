package ASM_StatementCoverage.ASM_SC;

import ASM_Coverage.*;

import java.io.FileOutputStream;
import java.lang.instrument.ClassFileTransformer;
import java.lang.instrument.IllegalClassFormatException;
import java.security.ProtectionDomain;

import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassWriter;

public class SC_ClassFileTransformer implements ClassFileTransformer {
	public byte[] transform(ClassLoader classLoader, String s, Class<?> className, ProtectionDomain protectionDomain,
			byte[] bytes) throws IllegalClassFormatException {

		byte[] byteCode = bytes;
		try {

			ClassReader cr = new ClassReader(bytes);
			ClassWriter cw = new ClassWriter(cr, 0);
			ClassTransformVisitor ca = new ClassTransformVisitor(cw);
			cr.accept(ca, 0);
			byteCode = cw.toByteArray();

			return byteCode;

		} catch (Exception ex) {
			ex.printStackTrace();
		}

		return byteCode;
	}
}