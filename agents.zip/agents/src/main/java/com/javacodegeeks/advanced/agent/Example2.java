package com.javacodegeeks.advanced.agent;

public class Example2 {
	public static void main(String[] args) {
		method1();
		method2();
	}
	public static int method1() {
		int a=1;	
		int b=1;
		int c=a+b;
		return c;
	}
	public static int method2() {
		int a=1;	
		int b=1;
		int c=a-b;
		return c;
	}
}
