package com.javacodegeeks.advanced.agent;
import java.util.HashMap;

import org.objectweb.asm.Label;
import org.objectweb.asm.MethodVisitor;
import org.objectweb.asm.Opcodes;

class MethodTransformVisitor extends MethodVisitor implements Opcodes {

	String mName;
	int lineNumber;
	
    public MethodTransformVisitor(final MethodVisitor mv, String name) {
        super(ASM5, mv);
        this.mName=name;
    }

    @Override
    public void visitCode(){
    	mv.visitFieldInsn(GETSTATIC, "java/lang/System", "out", "Ljava/io/PrintStream;");
    	mv.visitLdcInsn(mName+" executed");
    	mv.visitMethodInsn(INVOKEVIRTUAL, "java/io/PrintStream", "println", "(Ljava/lang/String;)V", false);  	
    }
    
    @Override
    public void visitLineNumber(int line, Label start) {
        this.lineNumber = line;
    	mv.visitFieldInsn(GETSTATIC, "java/lang/System", "out", "Ljava/io/PrintStream;");
    	mv.visitLdcInsn("line "+ line+" executed - " + "in method " + mName);
    	mv.visitMethodInsn(INVOKEVIRTUAL, "java/io/PrintStream", "println", "(Ljava/lang/String;)V", false);
    	super.visitLabel(start);
    	super.visitLineNumber(line, start);
    }
    
    public void MarkLineAsExecuted()
    {
    	HashMap<Integer, HashMap<String, String>> coverageHapmap = new HashMap<Integer, HashMap<String, String>>();
    	
    	
    	
    	
    }
}