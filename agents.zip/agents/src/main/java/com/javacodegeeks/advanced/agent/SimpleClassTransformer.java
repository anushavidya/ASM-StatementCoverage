package com.javacodegeeks.advanced.agent;

import java.io.File;
import java.io.FileOutputStream;
import java.lang.instrument.ClassFileTransformer;
import java.lang.instrument.IllegalClassFormatException;
import java.security.ProtectionDomain;

import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassWriter;

public class SimpleClassTransformer implements ClassFileTransformer {
	@Override
	public byte[] transform(final ClassLoader loader, final String className, final Class<?> classBeingRedefined,
			final ProtectionDomain protectionDomain, final byte[] classfileBuffer) throws IllegalClassFormatException {
		byte[] byteCode = classfileBuffer;
		try {
			if (className.contains("com/javacodegeeks/advanced/agent")) {
				ClassReader cr = new ClassReader(byteCode);
				ClassWriter cw = new ClassWriter(ClassWriter.COMPUTE_FRAMES);
				ClassParseVisitor ca = new ClassParseVisitor(cw);
				cr.accept(ca, 0);
				byteCode = cw.toByteArray();
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return byteCode;
	}
}
