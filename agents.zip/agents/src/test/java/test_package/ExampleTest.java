package test_package;

import com.javacodegeeks.advanced.agent.Example;

import org.junit.Test;

public class ExampleTest {

	@Test
	public void m1test() {
		Example.m1();
	}
	
	@Test
	public void m2test() {
		Example.m2();
	}

}
